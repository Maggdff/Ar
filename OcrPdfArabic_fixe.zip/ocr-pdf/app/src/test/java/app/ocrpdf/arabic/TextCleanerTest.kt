package app.ocrpdf.arabic

import app.ocrpdf.arabic.ocr.TextCleaner
import app.ocrpdf.arabic.ocr.Word
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class TextCleanerTest {
    @Test fun arabicOnlyStripsLatinNoiseAndWatermark() {
        val raw = "الكلام هو اللفظ Sa) المفيد\nتم المسح الضوئي بـ CamScanner"
        val out = TextCleaner.cleanText(raw, arabicOnly = true)
        assertEquals("الكلام هو اللفظ ) المفيد", out)
    }

    @Test fun mixedModeKeepsEnglish() {
        assertEquals("hello مرحبا", TextCleaner.cleanText("hello  مرحبا", arabicOnly = false))
    }

    @Test fun wordsDropEmptyAndWatermark() {
        val ws = listOf(Word("abc", 0, 0, 1, 1), Word("كلمة", 0, 0, 1, 1), Word("CamScanner", 0, 0, 1, 1))
        val out = TextCleaner.cleanWords(ws, arabicOnly = true)
        assertEquals(1, out.size)
        assertTrue(out[0].t == "كلمة")
    }
}
