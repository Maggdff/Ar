package app.ocrpdf.arabic.ocr

import android.graphics.Bitmap
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.*
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/** Thin, cancellable wrapper around Tesseract (LSTM engine). One instance = one language set. */
class OcrEngine(dataRoot: File, languages: String, dpi: Int) : AutoCloseable {
    data class Output(val text: String, val words: List<Word>)

    private val api = TessBaseAPI()

    init {
        val ok = api.init(dataRoot.absolutePath, languages, TessBaseAPI.OEM_LSTM_ONLY)
        if (!ok) {
            api.recycle()
            throw IllegalStateException("Tesseract init failed for '$languages'")
        }
        api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
        api.setVariable("user_defined_dpi", dpi.toString())
        api.setVariable("preserve_interword_spaces", "1")
        if (languages.trim() == "ara") api.setVariable("tessedit_char_blacklist", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz|~`")
    }

    /** Recognizes one page. Cancelling the calling coroutine stops Tesseract mid-page. */
    suspend fun recognize(bitmap: Bitmap): Output = withContext(Dispatchers.Default) {
        val finished = AtomicBoolean(false)
        val watcher = launch {
            try {
                awaitCancellation()
            } catch (e: CancellationException) {
                if (!finished.get()) api.stop()
                throw e
            }
        }
        try {
            doRecognize(bitmap)
        } finally {
            finished.set(true)
            watcher.cancel()
        }
    }

    private class Line(val paraStart: Boolean) {
        val words = ArrayList<Word>()
        val avgConf get() = if (words.isEmpty()) 0.0 else words.sumOf { it.c }.toDouble() / words.size
    }

    private fun doRecognize(bitmap: Bitmap): Output {
        api.setImage(bitmap)
        val raw = api.getUTF8Text() ?: ""        // triggers recognition
        val lines = ArrayList<Line>()
        val it = api.getResultIterator()
        if (it != null) {
            val wl = TessBaseAPI.PageIteratorLevel.RIL_WORD
            val ll = TessBaseAPI.PageIteratorLevel.RIL_TEXTLINE
            val pl = TessBaseAPI.PageIteratorLevel.RIL_PARA
            it.begin()
            var cur: Line? = null
            do {
                if (cur == null || it.isAtBeginningOf(ll)) {
                    cur = Line(it.isAtBeginningOf(pl)).also { l -> lines += l }
                }
                val w = it.getUTF8Text(wl)?.trim()
                if (!w.isNullOrEmpty()) {
                    val r = it.getBoundingRect(wl)
                    cur.words += Word(w, r.left, r.top, r.right, r.bottom, it.confidence(wl).toInt())
                }
            } while (it.next(wl))
            it.delete()
        }
        api.clear()
        if (lines.isEmpty()) return Output(raw.trim(), emptyList())

        // Handwriting, pen marks and smudges come out as low-confidence junk lines: drop them.
        val kept = lines.filter { l ->
            l.words.isNotEmpty() && l.avgConf >= MIN_LINE_CONF &&
                !(l.words.size <= 2 && l.avgConf < MIN_SHORT_LINE_CONF)
        }
        val words = kept.flatMap { l -> l.words.filter { it.c >= MIN_WORD_CONF } }
        val sb = StringBuilder()
        for (l in kept) {
            val t = l.words.filter { it.c >= MIN_WORD_CONF }.joinToString(" ") { it.t }
            if (t.isBlank()) continue
            if (sb.isNotEmpty()) sb.append(if (l.paraStart) "\n\n" else "\n")
            sb.append(t)
        }
        return Output(sb.toString().trim(), words)
    }

    private companion object {
        const val MIN_LINE_CONF = 45.0        // average word confidence (0-100) for a line to be kept
        const val MIN_SHORT_LINE_CONF = 70.0  // 1-2 word lines must be more certain (stray marks)
        const val MIN_WORD_CONF = 20
    }

    override fun close() {
        api.recycle()
    }
}
