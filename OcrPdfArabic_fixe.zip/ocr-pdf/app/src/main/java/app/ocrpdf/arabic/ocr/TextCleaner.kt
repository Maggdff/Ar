package app.ocrpdf.arabic.ocr

import java.text.Normalizer

/** Post-processing of raw Tesseract output (pure Kotlin, unit-testable). */
object TextCleaner {
    private val latin = Regex("[A-Za-z]+")
    private val spaces = Regex("[ \\t]{2,}")
    private val watermark = Regex("camscanner|scanned by|تم المسح الضوئي", RegexOption.IGNORE_CASE)

    /** Arabic-only mode: any Latin letters are recognition noise, not content. */
    fun isArabicOnly(languages: String) = languages.trim() == "ara"

    private fun norm(s: String) = Normalizer.normalize(s, Normalizer.Form.NFKC)   // presentation forms -> base letters

    fun isWatermark(s: String) = watermark.containsMatchIn(s)

    fun cleanText(text: String, arabicOnly: Boolean): String =
        text.lines().asSequence()
            .map { norm(it) }
            .filterNot { isWatermark(it) }
            .map { l -> (if (arabicOnly) latin.replace(l, "") else l).replace(spaces, " ").trim() }
            .joinToString("\n")
            .replace(Regex("\n{3,}"), "\n\n")
            .trim()

    fun cleanWords(words: List<Word>, arabicOnly: Boolean): List<Word> {
        val out = ArrayList<Word>(words.size)
        for (w in words) {
            var t = norm(w.t)
            if (isWatermark(t)) continue
            if (arabicOnly) t = latin.replace(t, "")
            t = t.trim()
            if (t.isEmpty()) continue
            out += w.copy(t = t)
        }
        return out
    }
}
