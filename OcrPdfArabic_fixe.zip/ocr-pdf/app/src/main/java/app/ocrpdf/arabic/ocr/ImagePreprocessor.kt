package app.ocrpdf.arabic.ocr

import android.graphics.Bitmap
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

/**
 * Cleans a rendered page before OCR (in place, low memory): grayscale -> local background estimate
 * (handles shadows / uneven lighting of phone scans), blue-pen marks removed -> adaptive binarization to crisp black-on-white.
 * Processes row by row, so it needs only ~1 byte per pixel extra.
 */
object ImagePreprocessor {
    private const val BLUE_MARGIN = 25
    private const val INK_RATIO = 0.85f   // a pixel is ink if darker than 85% of the local background

    fun enhance(bmp: Bitmap) {
        val w = bmp.width
        val h = bmp.height
        if (w < 16 || h < 16) return

        val gray = ByteArray(w * h)
        val row = IntArray(w)
        for (y in 0 until h) {
            bmp.getPixels(row, 0, w, 0, y, w, 1)
            val o = y * w
            for (x in 0 until w) {
                val c = row[x]
                val r = (c shr 16) and 0xFF
                val gr = (c shr 8) and 0xFF
                val b = c and 0xFF
                // Blue pen (handwriting, circles, underlines) is not printed text: erase it to white.
                val g = if (b > r + BLUE_MARGIN && b > gr + 5) 255 else (77 * r + 150 * gr + 29 * b) shr 8
                gray[o + x] = g.toByte()
            }
        }

        // Background level per tile = mean of the pixels brighter than the tile mean (ignores ink).
        val t = max(24, min(w, h) / 40)
        val tw = (w + t - 1) / t
        val th = (h + t - 1) / t
        val bg = FloatArray(tw * th)
        for (ty in 0 until th) for (tx in 0 until tw) {
            val x0 = tx * t; val x1 = min(w, x0 + t)
            val y0 = ty * t; val y1 = min(h, y0 + t)
            var sum = 0L; var n = 0
            for (y in y0 until y1) for (x in x0 until x1) { sum += gray[y * w + x].toInt() and 0xFF; n++ }
            val mean = sum.toFloat() / n
            var s2 = 0L; var n2 = 0
            for (y in y0 until y1) for (x in x0 until x1) {
                val g = gray[y * w + x].toInt() and 0xFF
                if (g >= mean) { s2 += g; n2++ }
            }
            bg[ty * tw + tx] = if (n2 > 0) s2.toFloat() / n2 else mean
        }
        // 3x3 smoothing to avoid seams between tiles.
        val sm = FloatArray(bg.size)
        for (ty in 0 until th) for (tx in 0 until tw) {
            var s = 0f; var n = 0
            for (dy in -1..1) for (dx in -1..1) {
                val yy = ty + dy; val xx = tx + dx
                if (yy in 0 until th && xx in 0 until tw) { s += bg[yy * tw + xx]; n++ }
            }
            sm[ty * tw + tx] = s / n
        }

        fun at(tx: Int, ty: Int) = sm[ty.coerceIn(0, th - 1) * tw + tx.coerceIn(0, tw - 1)]

        for (y in 0 until h) {
            val fy = y.toFloat() / t - 0.5f
            val ty0 = floor(fy).toInt()
            val wy = fy - ty0
            val o = y * w
            for (x in 0 until w) {
                val fx = x.toFloat() / t - 0.5f
                val tx0 = floor(fx).toInt()
                val wx = fx - tx0
                val top = at(tx0, ty0) * (1 - wx) + at(tx0 + 1, ty0) * wx
                val bot = at(tx0, ty0 + 1) * (1 - wx) + at(tx0 + 1, ty0 + 1) * wx
                val local = top * (1 - wy) + bot * wy
                val g = gray[o + x].toInt() and 0xFF
                row[x] = if (g < local * INK_RATIO) -0x1000000 else -0x1   // black / white (opaque)
            }
            bmp.setPixels(row, 0, w, 0, y, w, 1)
        }
    }
}
